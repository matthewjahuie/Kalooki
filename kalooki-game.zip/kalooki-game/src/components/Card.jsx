import { SUIT_SYMBOLS, RED_SUITS } from '../gameConfig';

export default function Card({ card, selected, onClick, small, faceDown, disabled }) {
  if (!card) return null;

  if (faceDown) {
    return (
      <div
        className={`card card-back ${small ? 'card-small' : ''}`}
        onClick={disabled ? undefined : onClick}
        style={{ cursor: disabled ? 'default' : 'pointer' }}
      />
    );
  }

  const isRed = card.isJoker ? false : RED_SUITS.has(card.suit);
  const symbol = card.isJoker ? '🃏' : SUIT_SYMBOLS[card.suit];
  const rank = card.isJoker ? 'JOK' : card.rank;

  return (
    <div
      className={`card ${isRed ? 'card-red' : 'card-black'} ${card.isJoker ? 'card-joker' : ''} ${selected ? 'card-selected' : ''} ${small ? 'card-small' : ''} ${disabled ? 'card-disabled' : ''}`}
      onClick={disabled ? undefined : onClick}
      title={card.isJoker ? 'Joker' : `${card.rank} of ${card.suit}`}
    >
      <div className="card-corner card-top-left">
        <div className="card-rank">{rank}</div>
        <div className="card-suit">{symbol}</div>
      </div>
      <div className="card-center">
        {card.isJoker ? (
          <span style={{ fontSize: '1.5rem' }}>🃏</span>
        ) : (
          <span className="card-suit-big">{symbol}</span>
        )}
      </div>
      <div className="card-corner card-bottom-right">
        <div className="card-rank">{rank}</div>
        <div className="card-suit">{symbol}</div>
      </div>
    </div>
  );
}
