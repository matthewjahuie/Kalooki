import { useState, useMemo } from 'react';
import Card from './Card';
import { isValidSet, isValidRun, canLayOff } from '../gameLogic';
import { ROUNDS } from '../gameConfig';

/**
 * MeldBuilder Modal
 * Props:
 *   hand: Card[]
 *   roundNumber: number (1-9)
 *   tableMelds: Meld[] (for Kalooki mode lay-offs)
 *   mode: 'open' | 'kalooki'
 *   onSubmit: (melds) => void   — melds includes contract melds + layoffs
 *   onCancel: () => void
 */
export default function MeldBuilder({ hand, roundNumber, tableMelds, mode, onSubmit, onCancel }) {
  const config = ROUNDS[roundNumber - 1];
  const totalRequired = config.sets + config.runs;

  // Each meld slot: { type: 'set'|'run', cards: [] }
  const [melds, setMelds] = useState(() =>
    Array.from({ length: totalRequired }, (_, i) => ({
      type: i < config.sets ? 'set' : 'run',
      cards: [],
    }))
  );

  // Lay-off assignments: [{ cardId, meldId }] (for kalooki mode extra cards)
  const [layoffs, setLayoffs] = useState([]);

  const [selectedCard, setSelectedCard] = useState(null); // card id
  const [activeMeldIdx, setActiveMeldIdx] = useState(null);
  const [activeMeldId, setActiveMeldId] = useState(null); // for table meld layoffs
  const [error, setError] = useState('');

  // Cards already assigned somewhere
  const assignedIds = useMemo(() => {
    const ids = new Set();
    melds.forEach(m => m.cards.forEach(c => ids.add(c.id)));
    layoffs.forEach(l => ids.add(l.cardId));
    return ids;
  }, [melds, layoffs]);

  const freeHand = hand.filter(c => !assignedIds.has(c.id));

  // Validate each meld slot
  const meldValidity = melds.map(m => {
    if (m.cards.length === 0) return null;
    return m.type === 'set' ? isValidSet(m.cards) : isValidRun(m.cards);
  });

  const allContractValid = melds.every((m, i) => {
    if (m.cards.length === 0) return false;
    return meldValidity[i] === true;
  });

  const allCardsAssigned = mode === 'kalooki' ? freeHand.length === 0 : true;
  const canSubmit = allContractValid && (mode !== 'kalooki' || allCardsAssigned);

  // ── Interaction handlers ──

  const handleCardClick = (card) => {
    setError('');
    if (selectedCard === card.id) {
      setSelectedCard(null);
      return;
    }
    setSelectedCard(card.id);
  };

  const handleAssignToMeld = (meldIdx) => {
    if (!selectedCard) return setActiveMeldIdx(meldIdx);
    const card = hand.find(c => c.id === selectedCard);
    if (!card) return;

    const newMelds = melds.map((m, i) => {
      if (i !== meldIdx) return m;
      return { ...m, cards: [...m.cards, card] };
    });
    setMelds(newMelds);
    setSelectedCard(null);
    setActiveMeldIdx(null);
  };

  const handleRemoveFromMeld = (meldIdx, cardId) => {
    const newMelds = melds.map((m, i) => {
      if (i !== meldIdx) return m;
      return { ...m, cards: m.cards.filter(c => c.id !== cardId) };
    });
    setMelds(newMelds);
  };

  const handleLayOffToTable = (tableMeld) => {
    if (!selectedCard) return;
    const card = hand.find(c => c.id === selectedCard);
    if (!card) return;
    if (!canLayOff(card, tableMeld)) {
      setError(`Can't lay ${card.rank} onto that meld`);
      return;
    }
    setLayoffs([...layoffs, { cardId: card.id, meldId: tableMeld.id, card }]);
    setSelectedCard(null);
  };

  const handleRemoveLayoff = (cardId) => {
    setLayoffs(layoffs.filter(l => l.cardId !== cardId));
  };

  const handleSubmit = () => {
    setError('');
    // Final validation
    for (let i = 0; i < melds.length; i++) {
      const m = melds[i];
      if (m.type === 'set' && !isValidSet(m.cards)) {
        return setError(`Meld ${i + 1} is not a valid set — need 3+ of the same rank`);
      }
      if (m.type === 'run' && !isValidRun(m.cards)) {
        return setError(`Meld ${i + 1} is not a valid run — need 4+ consecutive cards of same suit`);
      }
    }
    if (mode === 'kalooki' && freeHand.length > 0) {
      return setError(`You still have ${freeHand.length} unassigned card${freeHand.length > 1 ? 's' : ''} — assign them all to call Kalooki!`);
    }

    // Build the layoff-expanded table melds
    const layoffsByMeld = {};
    layoffs.forEach(l => {
      if (!layoffsByMeld[l.meldId]) layoffsByMeld[l.meldId] = [];
      layoffsByMeld[l.meldId].push(l.card);
    });

    onSubmit({ contractMelds: melds, layoffsByMeld });
  };

  return (
    <div className="modal-overlay">
      <div className="modal meld-builder">
        <div className="modal-header">
          <h2>
            {mode === 'kalooki' ? '⚡ CALL KALOOKI!' : '🂡 Open — Round ' + roundNumber}
          </h2>
          <p className="modal-subtitle">{config.label}</p>
          <button className="modal-close" onClick={onCancel}>✕</button>
        </div>

        {/* Contract Meld Slots */}
        <div className="meld-slots">
          {melds.map((meld, i) => {
            const valid = meldValidity[i];
            const isSet = meld.type === 'set';
            return (
              <div
                key={i}
                className={`meld-slot ${valid === true ? 'valid' : valid === false ? 'invalid' : ''} ${activeMeldIdx === i ? 'active' : ''}`}
                onClick={() => handleAssignToMeld(i)}
              >
                <div className="meld-slot-label">
                  {isSet ? `Set ${i < config.sets ? i + 1 : i - config.sets + 1}` : `Run ${i - config.sets + 1}`}
                  {' '}
                  <span className="meld-req">({isSet ? '3+ same rank' : '4+ same suit, in order'})</span>
                  {valid === true && <span className="meld-ok"> ✓</span>}
                  {valid === false && <span className="meld-err"> ✗</span>}
                </div>
                <div className="meld-slot-cards">
                  {meld.cards.map(card => (
                    <div key={card.id} className="meld-card-wrap">
                      <Card card={card} small onClick={() => handleRemoveFromMeld(i, card.id)} />
                      <button className="remove-card" onClick={(e) => { e.stopPropagation(); handleRemoveFromMeld(i, card.id); }}>×</button>
                    </div>
                  ))}
                  {meld.cards.length === 0 && (
                    <div className="meld-empty">
                      {selectedCard ? 'Tap here to assign selected card →' : 'Select a card below, then tap here'}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Table meld layoffs (Kalooki mode) */}
        {mode === 'kalooki' && tableMelds && tableMelds.length > 0 && (
          <div className="layoff-section">
            <h3>Lay off extra cards onto table melds</h3>
            <div className="table-meld-targets">
              {tableMelds.map(tm => (
                <div key={tm.id} className="table-meld-target" onClick={() => handleLayOffToTable(tm)}>
                  <div className="tm-label">{tm.type === 'set' ? '📦 Set' : '➡ Run'}</div>
                  <div className="tm-cards">
                    {tm.cards.slice(-4).map(c => <Card key={c.id} card={c} small />)}
                    {/* Show layoff cards */}
                    {layoffs.filter(l => l.meldId === tm.id).map(l => (
                      <div key={l.cardId} className="meld-card-wrap">
                        <Card card={l.card} small />
                        <button className="remove-card" onClick={e => { e.stopPropagation(); handleRemoveLayoff(l.cardId); }}>×</button>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Your hand */}
        <div className="builder-hand">
          <h3>Your Cards {freeHand.length > 0 ? `(${freeHand.length} unassigned)` : '✓ All assigned!'}</h3>
          <div className="hand-cards">
            {hand.map(card => {
              const isAssigned = assignedIds.has(card.id);
              return (
                <div key={card.id} className={`builder-card-wrap ${isAssigned ? 'assigned' : ''}`}>
                  <Card
                    card={card}
                    selected={selectedCard === card.id}
                    onClick={() => !isAssigned && handleCardClick(card)}
                    disabled={isAssigned}
                    small
                  />
                </div>
              );
            })}
          </div>
        </div>

        {error && <div className="error-banner">{error}</div>}

        <div className="modal-actions">
          <button className="btn btn-ghost" onClick={onCancel}>Cancel</button>
          <button
            className={`btn ${mode === 'kalooki' ? 'btn-kalooki' : 'btn-primary'}`}
            onClick={handleSubmit}
            disabled={!canSubmit}
          >
            {mode === 'kalooki' ? '⚡ KALOOKI!' : '✓ Open'}
          </button>
        </div>
      </div>
    </div>
  );
}
