import { useState } from 'react';
import { createRoom, joinRoom } from '../gameActions';

export default function Lobby({ onJoin }) {
  const [name, setName] = useState('');
  const [roomCode, setRoomCode] = useState('');
  const [mode, setMode] = useState('home'); // home | create | join
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleCreate = async () => {
    if (!name.trim()) return setError('Enter your name first');
    setLoading(true);
    setError('');
    try {
      const { roomId, playerId } = await createRoom(name.trim());
      onJoin(roomId, playerId, name.trim());
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleJoin = async () => {
    if (!name.trim()) return setError('Enter your name first');
    if (!roomCode.trim()) return setError('Enter a room code');
    setLoading(true);
    setError('');
    try {
      const { roomId, playerId } = await joinRoom(roomCode.trim(), name.trim());
      onJoin(roomId, playerId, name.trim());
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="lobby">
      <div className="lobby-card">
        <div className="lobby-logo">
          <span className="lobby-suit">♠</span>
          <h1>Kalooki</h1>
          <span className="lobby-suit">♥</span>
        </div>
        <p className="lobby-sub">Progressive Kalooki · 9 Rounds · Family Edition</p>

        {mode === 'home' && (
          <div className="lobby-buttons">
            <button className="btn btn-primary" onClick={() => setMode('create')}>
              🂡 Create Room
            </button>
            <button className="btn btn-secondary" onClick={() => setMode('join')}>
              🚪 Join Room
            </button>
          </div>
        )}

        {(mode === 'create' || mode === 'join') && (
          <div className="lobby-form">
            <div className="form-group">
              <label>Your Name</label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. Grandma, Cousin Dee..."
                maxLength={20}
                onKeyDown={e => e.key === 'Enter' && (mode === 'create' ? handleCreate() : handleJoin())}
                autoFocus
              />
            </div>

            {mode === 'join' && (
              <div className="form-group">
                <label>Room Code</label>
                <input
                  type="text"
                  value={roomCode}
                  onChange={e => setRoomCode(e.target.value.trim())}
                  placeholder="Paste the room code here"
                  onKeyDown={e => e.key === 'Enter' && handleJoin()}
                />
              </div>
            )}

            {error && <div className="error-msg">{error}</div>}

            <div className="lobby-buttons">
              <button
                className="btn btn-primary"
                onClick={mode === 'create' ? handleCreate : handleJoin}
                disabled={loading}
              >
                {loading ? 'Loading…' : mode === 'create' ? '✓ Create Game' : '→ Join Game'}
              </button>
              <button className="btn btn-ghost" onClick={() => { setMode('home'); setError(''); }}>
                ← Back
              </button>
            </div>
          </div>
        )}

        <div className="lobby-rules">
          <p>🃏 2 decks · 4 Jokers · 9 Progressive Rounds</p>
          <p>🏆 Lowest score after Round 9 wins</p>
          <p>⚡ First to tap the Call Button grabs the discard</p>
        </div>
      </div>
    </div>
  );
}
