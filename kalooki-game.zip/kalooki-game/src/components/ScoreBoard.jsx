import { ROUNDS } from '../gameConfig';
import { advanceRound } from '../gameActions';

export default function ScoreBoard({ roomData, playerId, onLeave }) {
  const { game, players, playerOrder, host, id: roomId } = roomData;
  const isHost = playerId === host;
  const isGameOver = roomData.status === 'gameOver' || game?.phase === 'gameOver';

  const sortedPlayers = [...(playerOrder || [])].sort((a, b) => {
    const scoreA = players[a]?.totalScore ?? 0;
    const scoreB = players[b]?.totalScore ?? 0;
    return scoreA - scoreB;
  });

  const winner = sortedPlayers[0];
  const roundScores = game?.roundScores || {};
  const currentRound = game?.round || 1;

  const handleNext = async () => {
    try {
      await advanceRound(roomId, playerId);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="scoreboard-overlay">
      <div className="scoreboard-card">
        {isGameOver ? (
          <>
            <div className="scoreboard-title">🏆 Game Over!</div>
            <div className="scoreboard-winner">
              {players[winner]?.name} wins!
            </div>
          </>
        ) : (
          <>
            <div className="scoreboard-title">Round {currentRound} Complete</div>
            {game?.kalookiCaller && (
              <div className="kalooki-announce">
                ⚡ {players[game.kalookiCaller]?.name} called KALOOKI! Everyone else gets double points!
              </div>
            )}
          </>
        )}

        <table className="score-table">
          <thead>
            <tr>
              <th>Player</th>
              <th>This Round</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            {sortedPlayers.map((pid, rank) => (
              <tr key={pid} className={pid === playerId ? 'my-row' : ''}>
                <td>
                  {rank === 0 && !isGameOver && '🥇 '}
                  {rank === 0 && isGameOver && '🏆 '}
                  {players[pid]?.name}
                  {pid === playerId && ' (you)'}
                </td>
                <td className={roundScores[pid] === 0 ? 'score-zero' : 'score-nonzero'}>
                  {roundScores[pid] !== undefined ? (roundScores[pid] === 0 ? '★ 0' : `+${roundScores[pid]}`) : '—'}
                </td>
                <td className="score-total">{players[pid]?.totalScore ?? 0}</td>
              </tr>
            ))}
          </tbody>
        </table>

        {!isGameOver && currentRound < 9 && (
          <div className="next-round-info">
            <strong>Next: Round {currentRound + 1}</strong> — {ROUNDS[currentRound]?.label}
          </div>
        )}

        <div className="scoreboard-actions">
          {isGameOver ? (
            <button className="btn btn-primary" onClick={onLeave}>🚪 Leave Game</button>
          ) : (
            isHost ? (
              <button className="btn btn-primary" onClick={handleNext}>
                ▶ Start Round {currentRound + 1}
              </button>
            ) : (
              <p className="waiting-msg">Waiting for {players[host]?.name} to start the next round…</p>
            )
          )}
        </div>
      </div>
    </div>
  );
}
