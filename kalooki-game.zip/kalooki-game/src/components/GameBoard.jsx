import { useState, useEffect, useMemo, useRef } from 'react';
import Card from './Card';
import MeldBuilder from './MeldBuilder';
import ScoreBoard from './ScoreBoard';
import {
  startGame, drawFromDeck, takeDiscard, openMelds,
  layOff, replaceJoker, discardCard, claimCallButton,
  callKalooki, sendChat,
} from '../gameActions';
import { canLayOff, canReplaceJoker, sortHand, validateOpening } from '../gameLogic';
import { ROUNDS, getCardValue } from '../gameConfig';

export default function GameBoard({ roomData, playerId, playerName, roomId, onLeave }) {
  const { game, players, playerOrder, host, status } = roomData;

  const [selectedCards, setSelectedCards] = useState(new Set());
  const [showMeldBuilder, setShowMeldBuilder] = useState(false);
  const [meldMode, setMeldMode] = useState('open'); // 'open' | 'kalooki'
  const [chatOpen, setChatOpen] = useState(false);
  const [chatMsg, setChatMsg] = useState('');
  const [toast, setToast] = useState('');
  const [replaceMode, setReplaceMode] = useState(false); // selecting joker target
  const [callActive, setCallActive] = useState(false);
  const [callCountdown, setCallCountdown] = useState(0);
  const chatEndRef = useRef(null);
  const prevPhase = useRef(null);

  const isHost = playerId === host;
  const isWaiting = status === 'waiting';

  // Derived game state
  const myHand = useMemo(() => {
    if (!game?.hands?.[playerId]) return [];
    const h = game.hands[playerId];
    return Array.isArray(h) ? h : Object.values(h);
  }, [game?.hands, playerId]);

  const tableMelds = useMemo(() => {
    if (!game?.tableMelds) return [];
    return Array.isArray(game.tableMelds) ? game.tableMelds : Object.values(game.tableMelds);
  }, [game?.tableMelds]);

  const discardPile = useMemo(() => {
    if (!game?.discardPile) return [];
    return Array.isArray(game.discardPile) ? game.discardPile : Object.values(game.discardPile);
  }, [game?.discardPile]);

  const topDiscard = discardPile[discardPile.length - 1];
  const currentPlayer = playerOrder?.[game?.currentPlayerIdx ?? 0];
  const isMyTurn = currentPlayer === playerId;
  const phase = game?.phase;
  const roundConfig = game?.round ? ROUNDS[game.round - 1] : null;
  const iOpened = game?.openedPlayers?.includes(playerId);
  const callWindowActive = game?.callWindow?.active && !game?.callWindow?.claimedBy;
  const isCallingWindow = phase === 'calling';

  // Sort hand for display
  const sortedHand = useMemo(() => sortHand(myHand), [myHand]);

  // ── Call button countdown ──
  useEffect(() => {
    if (!isCallingWindow || !game?.callWindow?.expiresAt) {
      setCallActive(false);
      return;
    }
    setCallActive(true);
    const tick = setInterval(() => {
      const remaining = Math.max(0, game.callWindow.expiresAt - Date.now());
      setCallCountdown(Math.ceil(remaining / 1000));
      if (remaining <= 0) {
        setCallActive(false);
        clearInterval(tick);
      }
    }, 200);
    return () => clearInterval(tick);
  }, [isCallingWindow, game?.callWindow?.expiresAt]);

  // ── Toast notifications ──
  const showToast = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(''), 3000);
  };

  useEffect(() => {
    if (!phase || phase === prevPhase.current) return;
    prevPhase.current = phase;
    if (phase === 'calling' && game?.callWindow?.card) {
      const discarded = game.callWindow.card;
      const name = players[currentPlayer]?.name;
      showToast(`${name} discarded ${discarded.rank}${discarded.isJoker ? '' : ' of ' + discarded.suit}!`);
    }
  }, [phase]);

  // ── Chat scroll ──
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [roomData.chat]);

  // ── Action helpers ──

  const toggleCard = (card) => {
    setSelectedCards(prev => {
      const next = new Set(prev);
      if (next.has(card.id)) next.delete(card.id);
      else next.add(card.id);
      return next;
    });
  };

  const selectedCardObjects = myHand.filter(c => selectedCards.has(c.id));
  const oneSelected = selectedCardObjects.length === 1 ? selectedCardObjects[0] : null;

  const handleDraw = async () => {
    try { await drawFromDeck(roomId, playerId); }
    catch (e) { showToast('Error: ' + e.message); }
  };

  const handleTakeDiscard = async () => {
    if (!topDiscard) return;
    try { await takeDiscard(roomId, playerId); }
    catch (e) { showToast('Error: ' + e.message); }
  };

  const handleDiscard = async () => {
    if (!oneSelected) return showToast('Select exactly 1 card to discard');
    setSelectedCards(new Set());
    try { await discardCard(roomId, playerId, oneSelected.id); }
    catch (e) { showToast('Error: ' + e.message); }
  };

  const handleOpen = () => {
    if (!iOpened) {
      setMeldMode('open');
      setShowMeldBuilder(true);
    }
  };

  const handleKalooki = () => {
    setMeldMode('kalooki');
    setShowMeldBuilder(true);
  };

  const handleMeldSubmit = async ({ contractMelds, layoffsByMeld }) => {
    setShowMeldBuilder(false);
    try {
      if (meldMode === 'kalooki') {
        // Build full meld list: contract melds extended by layoffs
        const fullMelds = contractMelds.map(m => {
          const layoffCards = layoffsByMeld[m.id] || [];
          return { ...m, cards: [...m.cards, ...layoffCards] };
        });
        // Also build layoffs to existing table melds as updates
        await callKalooki(roomId, playerId, fullMelds);
        showToast('KALOOKI! 🎉');
      } else {
        const { valid, error } = validateOpening(contractMelds, roundConfig);
        if (!valid) return showToast(error);
        await openMelds(roomId, playerId, contractMelds);
        showToast('You opened! 🎉');
      }
    } catch (e) {
      showToast('Error: ' + e.message);
    }
  };

  const handleLayOff = async (meld) => {
    if (!oneSelected) return showToast('Select a card first');
    if (!canLayOff(oneSelected, meld)) return showToast(`Can't lay ${oneSelected.rank} onto that meld`);
    setSelectedCards(new Set());
    try { await layOff(roomId, playerId, oneSelected.id, meld.id); }
    catch (e) { showToast('Error: ' + e.message); }
  };

  const handleReplaceJoker = async (meld) => {
    if (!oneSelected) return showToast('Select a card first');
    const { canReplace, jokerIndex } = canReplaceJoker(oneSelected, meld);
    if (!canReplace) return showToast(`Can't replace joker with ${oneSelected.rank} of ${oneSelected.suit}`);
    setSelectedCards(new Set());
    setReplaceMode(false);
    try { await replaceJoker(roomId, playerId, oneSelected.id, meld.id, jokerIndex); showToast('Joker replaced! 🔄'); }
    catch (e) { showToast('Error: ' + e.message); }
  };

  const handleCallButton = async () => {
    if (!callWindowActive || isMyTurn) return;
    try {
      const claimed = await claimCallButton(roomId, playerId);
      if (claimed) showToast('You grabbed the card! 🤙');
      else showToast('Too slow! Someone else got it.');
    } catch (e) { showToast('Error: ' + e.message); }
  };

  const handleStartGame = async () => {
    if (!isHost) return;
    try { await startGame(roomId, playerId); }
    catch (e) { showToast('Error: ' + e.message); }
  };

  const handleSendChat = async () => {
    if (!chatMsg.trim()) return;
    await sendChat(roomId, playerId, playerName, chatMsg.trim());
    setChatMsg('');
  };

  // ── Hand score preview ──
  const myHandScore = myHand.reduce((s, c) => s + getCardValue(c), 0);

  // ── Show scoreboard between rounds ──
  const showScoreBoard = phase === 'roundEnd' || phase === 'gameOver' || status === 'gameOver';

  // ── Waiting lobby ──
  if (isWaiting) {
    return (
      <div className="waiting-room">
        <div className="waiting-card">
          <h2>🃏 Waiting Room</h2>
          <p className="room-code-label">Share this Room Code:</p>
          <div className="room-code">{roomId}</div>
          <div className="waiting-players">
            {(playerOrder || []).map(pid => (
              <div key={pid} className={`waiting-player ${pid === playerId ? 'me' : ''}`}>
                {pid === host ? '👑 ' : '🎮 '}
                {players[pid]?.name}
                {pid === playerId ? ' (you)' : ''}
              </div>
            ))}
          </div>
          {isHost ? (
            <button
              className="btn btn-primary"
              onClick={handleStartGame}
              disabled={(playerOrder || []).length < 2}
            >
              {(playerOrder || []).length < 2 ? 'Need at least 2 players…' : '▶ Start Game'}
            </button>
          ) : (
            <p className="waiting-msg">Waiting for {players[host]?.name} to start…</p>
          )}
          <button className="btn btn-ghost" onClick={onLeave}>🚪 Leave</button>
        </div>
      </div>
    );
  }

  return (
    <div className="gameboard">
      {/* ── Scoreboard overlay ── */}
      {showScoreBoard && (
        <ScoreBoard roomData={roomData} playerId={playerId} onLeave={onLeave} />
      )}

      {/* ── MeldBuilder modal ── */}
      {showMeldBuilder && (
        <MeldBuilder
          hand={myHand}
          roundNumber={game.round}
          tableMelds={tableMelds}
          mode={meldMode}
          onSubmit={handleMeldSubmit}
          onCancel={() => setShowMeldBuilder(false)}
        />
      )}

      {/* ── Toast ── */}
      {toast && <div className="toast">{toast}</div>}

      {/* ── Header ── */}
      <header className="game-header">
        <div className="header-left">
          <span className="round-badge">Round {game?.round ?? '?'}/9</span>
          <span className="contract-label">{roundConfig?.label}</span>
        </div>
        <div className="header-center">
          <span className="logo-small">♠ Kalooki ♥</span>
        </div>
        <div className="header-right">
          <button className="btn-icon" onClick={() => setChatOpen(c => !c)} title="Chat">💬</button>
          <button className="btn-icon" onClick={onLeave} title="Leave">🚪</button>
        </div>
      </header>

      {/* ── Other Players ── */}
      <div className="other-players">
        {(playerOrder || []).filter(pid => pid !== playerId).map(pid => {
          const hand = game?.hands?.[pid];
          const handArr = Array.isArray(hand) ? hand : Object.values(hand || {});
          const isActive = pid === currentPlayer;
          const opened = game?.openedPlayers?.includes(pid);
          return (
            <div key={pid} className={`other-player ${isActive ? 'active-player' : ''}`}>
              <div className="op-name">
                {isActive && <span className="turn-arrow">▶ </span>}
                {players[pid]?.name}
                {opened && <span className="opened-badge">✓ opened</span>}
              </div>
              <div className="op-cards">
                {handArr.slice(0, 16).map((_, i) => (
                  <div key={i} className="op-card-back" />
                ))}
                <span className="op-count">{handArr.length}</span>
              </div>
              <div className="op-score">{players[pid]?.totalScore ?? 0} pts</div>
            </div>
          );
        })}
      </div>

      {/* ── Table Melds ── */}
      {tableMelds.length > 0 && (
        <div className="table-melds-area">
          <div className="table-melds-label">Table Melds</div>
          <div className="table-melds-list">
            {tableMelds.map(meld => {
              const meldCards = Array.isArray(meld.cards) ? meld.cards : Object.values(meld.cards || {});
              const canLay = oneSelected && iOpened && isMyTurn && phase === 'action' && canLayOff(oneSelected, meld);
              const canReplace = oneSelected && isMyTurn && phase === 'action' && canReplaceJoker(oneSelected, meld).canReplace;
              return (
                <div key={meld.id} className="table-meld">
                  <div className="meld-owner">{players[meld.playerId]?.name} · {meld.type}</div>
                  <div className="meld-cards">
                    {meldCards.map(c => <Card key={c.id} card={c} small />)}
                  </div>
                  <div className="meld-actions">
                    {canLay && (
                      <button className="btn-small btn-layoff" onClick={() => handleLayOff(meld)}>
                        + Lay Off
                      </button>
                    )}
                    {canReplace && (
                      <button className="btn-small btn-replace" onClick={() => handleReplaceJoker(meld)}>
                        🔄 Replace Joker
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── Draw & Discard Piles + Call Button ── */}
      <div className="piles-area">
        {/* Deck */}
        <div className="pile-wrap">
          <div className="pile-label">Draw Pile</div>
          <div
            className={`pile deck-pile ${isMyTurn && phase === 'draw' ? 'clickable' : ''}`}
            onClick={isMyTurn && phase === 'draw' ? handleDraw : undefined}
          >
            <Card card={{ suit: 'back', rank: 'back', id: 'deck', isJoker: false }} faceDown />
            <span className="pile-count">{game?.deck?.length ?? 0}</span>
          </div>
        </div>

        {/* Call Button — big, prominent, pulsing when active */}
        <div className="call-btn-wrap">
          {isCallingWindow && !isMyTurn ? (
            <button
              className={`call-button ${callActive ? 'call-active' : 'call-inactive'}`}
              onClick={handleCallButton}
              disabled={!callActive}
            >
              <span className="call-label">CALL!</span>
              {callCountdown > 0 && <span className="call-countdown">{callCountdown}s</span>}
            </button>
          ) : (
            <div className="call-button-placeholder">
              <span>⚡</span>
            </div>
          )}
        </div>

        {/* Discard Pile */}
        <div className="pile-wrap">
          <div className="pile-label">Discard</div>
          <div
            className={`pile discard-pile ${isMyTurn && phase === 'draw' && topDiscard ? 'clickable' : ''}`}
            onClick={isMyTurn && phase === 'draw' && topDiscard ? handleTakeDiscard : undefined}
          >
            {topDiscard ? <Card card={topDiscard} /> : <div className="pile-empty">Empty</div>}
          </div>
        </div>
      </div>

      {/* ── Turn Status ── */}
      <div className="turn-status">
        {isMyTurn ? (
          <span className="my-turn-label">
            {phase === 'draw' && '👆 Your turn — Draw from deck or take discard'}
            {phase === 'action' && '🃏 Play your hand or discard'}
            {phase === 'discard' && '🗑 Discard a card'}
            {phase === 'calling' && '⌛ Call window…'}
          </span>
        ) : (
          <span className="wait-label">
            {isCallingWindow
              ? `Tap CALL to grab the discard! (${callCountdown}s)`
              : `Waiting for ${players[currentPlayer]?.name}…`}
          </span>
        )}
      </div>

      {/* ── Action Buttons ── */}
      {isMyTurn && (
        <div className="action-buttons">
          {!iOpened && phase === 'action' && (
            <button className="btn btn-open" onClick={handleOpen}>
              🂡 Open
            </button>
          )}
          {!iOpened && phase === 'action' && (
            <button className="btn btn-kalooki" onClick={handleKalooki}>
              ⚡ Kalooki!
            </button>
          )}
          {phase === 'action' && (
            <button
              className="btn btn-discard"
              onClick={handleDiscard}
              disabled={selectedCards.size !== 1}
            >
              🗑 Discard
            </button>
          )}
        </div>
      )}

      {/* ── My Hand ── */}
      <div className="my-hand-area">
        <div className="my-hand-header">
          <span className="hand-label">
            Your Hand ({myHand.length} cards
            {iOpened ? ' · opened ✓' : ''})
          </span>
          <span className="hand-score">Hand value: {myHandScore} pts</span>
        </div>
        <div className="my-hand-cards">
          {sortedHand.map(card => (
            <Card
              key={card.id}
              card={card}
              selected={selectedCards.has(card.id)}
              onClick={() => toggleCard(card)}
              disabled={(!isMyTurn && !isCallingWindow) || phase === 'draw'}
            />
          ))}
        </div>
      </div>

      {/* ── Chat Panel ── */}
      {chatOpen && (
        <div className="chat-panel">
          <div className="chat-header">
            <span>💬 Chat</span>
            <button onClick={() => setChatOpen(false)}>✕</button>
          </div>
          <div className="chat-messages">
            {roomData.chat ? Object.values(roomData.chat).map((msg, i) => (
              <div key={i} className={`chat-msg ${msg.playerId === playerId ? 'my-msg' : ''}`}>
                <span className="chat-name">{msg.name}:</span> {msg.text}
              </div>
            )) : <div className="chat-empty">No messages yet</div>}
            <div ref={chatEndRef} />
          </div>
          <div className="chat-input">
            <input
              type="text"
              value={chatMsg}
              onChange={e => setChatMsg(e.target.value)}
              placeholder="Type a message…"
              onKeyDown={e => e.key === 'Enter' && handleSendChat()}
              maxLength={200}
            />
            <button onClick={handleSendChat}>Send</button>
          </div>
        </div>
      )}
    </div>
  );
}
