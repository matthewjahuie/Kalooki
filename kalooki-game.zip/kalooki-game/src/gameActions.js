import { ref, set, update, get, runTransaction, push } from 'firebase/database';
import { db } from './firebase';
import { ROUNDS, createDeck, shuffleDeck, calcHandScore } from './gameConfig';

// ─── Room Management ─────────────────────────────────────────────────────────

export async function createRoom(playerName) {
  const roomRef = push(ref(db, 'rooms'));
  const roomId = roomRef.key;
  const playerId = `player_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;

  await set(roomRef, {
    id: roomId,
    status: 'waiting',
    host: playerId,
    playerOrder: [playerId],
    players: {
      [playerId]: {
        id: playerId,
        name: playerName,
        connected: true,
        totalScore: 0,
      },
    },
    game: null,
    chat: null,
  });

  return { roomId, playerId };
}

export async function joinRoom(roomId, playerName) {
  const roomRef = ref(db, `rooms/${roomId}`);
  const snap = await get(roomRef);
  if (!snap.exists()) throw new Error('Room not found');

  const room = snap.val();
  if (room.status !== 'waiting') throw new Error('Game already in progress');

  const playerCount = Object.keys(room.players || {}).length;
  if (playerCount >= 6) throw new Error('Room is full (max 6 players)');

  const playerId = `player_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const playerOrder = [...(room.playerOrder || []), playerId];

  await update(ref(db, `rooms/${roomId}`), {
    [`players/${playerId}`]: {
      id: playerId,
      name: playerName,
      connected: true,
      totalScore: 0,
    },
    playerOrder,
  });

  return { roomId, playerId };
}

export async function sendChat(roomId, playerId, playerName, text) {
  const msgRef = push(ref(db, `rooms/${roomId}/chat`));
  await set(msgRef, {
    playerId,
    name: playerName,
    text,
    ts: Date.now(),
  });
}

// ─── Game Start / Round Setup ─────────────────────────────────────────────────

export async function startGame(roomId, hostId) {
  await startRound(roomId, 1, hostId);
  await update(ref(db, `rooms/${roomId}`), { status: 'playing' });
}

export async function startRound(roomId, roundNumber, hostId) {
  const roomRef = ref(db, `rooms/${roomId}`);
  const snap = await get(roomRef);
  const room = snap.val();

  const config = ROUNDS[roundNumber - 1];
  const playerOrder = room.playerOrder;

  // Build deck, shuffle, deal
  const deck = shuffleDeck(createDeck());
  const hands = {};
  let deckIdx = 0;

  for (const pid of playerOrder) {
    hands[pid] = [];
    for (let i = 0; i < config.cards; i++) {
      hands[pid].push(deck[deckIdx++]);
    }
  }

  const remainingDeck = deck.slice(deckIdx);
  const topDiscard = remainingDeck.pop();

  const game = {
    round: roundNumber,
    currentPlayerIdx: 0,
    phase: 'draw', // draw | action | calling | discard | roundEnd
    deck: remainingDeck,
    discardPile: [topDiscard],
    hands,
    tableMelds: [],
    openedPlayers: [],
    kalookiCaller: null,
    callWindow: {
      active: false,
      card: null,
      claimedBy: null,
    },
    roundScores: {},
  };

  await update(ref(db, `rooms/${roomId}`), { game });
}

// ─── Turn Actions ─────────────────────────────────────────────────────────────

export async function drawFromDeck(roomId, playerId) {
  const gameRef = ref(db, `rooms/${roomId}/game`);
  const snap = await get(gameRef);
  const game = snap.val();

  let deck = [...(game.deck || [])];
  const discardPile = [...(game.discardPile || [])];

  // Reshuffle discard into deck if empty (keep top card)
  if (deck.length === 0) {
    if (discardPile.length <= 1) return; // nothing to draw
    const top = discardPile.pop();
    deck = shuffleDeck(discardPile);
    discardPile.length = 0;
    discardPile.push(top);
  }

  const drawn = deck.pop();
  const hand = [...(game.hands[playerId] || []), drawn];

  await update(gameRef, {
    deck,
    discardPile,
    [`hands/${playerId}`]: hand,
    phase: 'action',
  });
}

export async function takeDiscard(roomId, playerId) {
  const gameRef = ref(db, `rooms/${roomId}/game`);
  const snap = await get(gameRef);
  const game = snap.val();

  const discardPile = [...(game.discardPile || [])];
  if (discardPile.length === 0) return;

  const taken = discardPile.pop();
  const hand = [...(game.hands[playerId] || []), taken];

  await update(gameRef, {
    discardPile,
    [`hands/${playerId}`]: hand,
    phase: 'action',
  });
}

/** Open contract melds */
export async function openMelds(roomId, playerId, melds) {
  // melds: [{ type: 'set'|'run', cards: [] }, ...]
  const gameRef = ref(db, `rooms/${roomId}/game`);
  const snap = await get(gameRef);
  const game = snap.val();

  const meldCardIds = new Set(melds.flatMap(m => m.cards.map(c => c.id)));
  const newHand = (game.hands[playerId] || []).filter(c => !meldCardIds.has(c.id));

  const existingMelds = game.tableMelds ? (Array.isArray(game.tableMelds) ? game.tableMelds : Object.values(game.tableMelds)) : [];
  const newMelds = [
    ...existingMelds,
    ...melds.map((m, i) => ({
      id: `meld_${playerId}_${Date.now()}_${i}`,
      playerId,
      type: m.type,
      cards: m.cards,
    })),
  ];

  const openedPlayers = [...(game.openedPlayers || [])];
  if (!openedPlayers.includes(playerId)) openedPlayers.push(playerId);

  await update(gameRef, {
    [`hands/${playerId}`]: newHand,
    tableMelds: newMelds,
    openedPlayers,
    phase: 'action',
  });
}

/** Lay a card off onto an existing table meld */
export async function layOff(roomId, playerId, cardId, meldId) {
  const gameRef = ref(db, `rooms/${roomId}/game`);
  const snap = await get(gameRef);
  const game = snap.val();

  const hand = [...(game.hands[playerId] || [])];
  const cardIdx = hand.findIndex(c => c.id === cardId);
  if (cardIdx === -1) return;
  const [card] = hand.splice(cardIdx, 1);

  const melds = Array.isArray(game.tableMelds)
    ? [...game.tableMelds]
    : Object.values(game.tableMelds || {});

  const meldIdx = melds.findIndex(m => m.id === meldId);
  if (meldIdx === -1) return;
  melds[meldIdx] = { ...melds[meldIdx], cards: [...melds[meldIdx].cards, card] };

  await update(gameRef, {
    [`hands/${playerId}`]: hand,
    tableMelds: melds,
  });
}

/** Replace a joker in a table meld with a natural card from hand */
export async function replaceJoker(roomId, playerId, cardId, meldId, jokerIndex) {
  const gameRef = ref(db, `rooms/${roomId}/game`);
  const snap = await get(gameRef);
  const game = snap.val();

  const hand = [...(game.hands[playerId] || [])];
  const cardIdx = hand.findIndex(c => c.id === cardId);
  if (cardIdx === -1) return;
  const [naturalCard] = hand.splice(cardIdx, 1);

  const melds = Array.isArray(game.tableMelds)
    ? [...game.tableMelds]
    : Object.values(game.tableMelds || {});

  const meldIdx = melds.findIndex(m => m.id === meldId);
  if (meldIdx === -1) return;

  const meldCards = [...melds[meldIdx].cards];
  const joker = meldCards[jokerIndex];
  meldCards[jokerIndex] = naturalCard;
  hand.push(joker); // joker goes back to player's hand

  melds[meldIdx] = { ...melds[meldIdx], cards: meldCards };

  await update(gameRef, {
    [`hands/${playerId}`]: hand,
    tableMelds: melds,
  });
}

/** Discard a card — triggers call window for other players */
export async function discardCard(roomId, playerId, cardId) {
  const gameRef = ref(db, `rooms/${roomId}/game`);
  const snap = await get(gameRef);
  const game = snap.val();

  const hand = [...(game.hands[playerId] || [])];
  const cardIdx = hand.findIndex(c => c.id === cardId);
  if (cardIdx === -1) return;
  const [card] = hand.splice(cardIdx, 1);

  const discardPile = [...(game.discardPile || []), card];

  const roomSnap = await get(ref(db, `rooms/${roomId}`));
  const room = roomSnap.val();
  const playerOrder = room.playerOrder;

  // Check if player has gone out
  if (hand.length === 0) {
    // Player wins the round
    await _endRound(roomId, playerId, false, game, hand, discardPile, playerOrder);
    return;
  }

  await update(gameRef, {
    [`hands/${playerId}`]: hand,
    discardPile,
    phase: 'calling',
    callWindow: {
      active: true,
      card,
      claimedBy: null,
      expiresAt: Date.now() + 8000, // 8 second window
    },
  });

  // Auto-advance after 8 seconds if nobody calls
  setTimeout(async () => {
    const freshSnap = await get(gameRef);
    const freshGame = freshSnap.val();
    if (freshGame?.callWindow?.active && !freshGame?.callWindow?.claimedBy) {
      // Nobody called — advance to next player
      const currentPlayerOrder = (await get(ref(db, `rooms/${roomId}/playerOrder`))).val();
      const nextIdx = (freshGame.currentPlayerIdx + 1) % currentPlayerOrder.length;
      await update(gameRef, {
        'callWindow/active': false,
        currentPlayerIdx: nextIdx,
        phase: 'draw',
      });
    }
  }, 8500);
}

/** Claim the call button — Firebase transaction ensures only first tap wins */
export async function claimCallButton(roomId, playerId) {
  const claimRef = ref(db, `rooms/${roomId}/game/callWindow/claimedBy`);

  const result = await runTransaction(claimRef, (current) => {
    if (current === null || current === undefined) {
      return playerId; // Claim it!
    }
    return undefined; // Already claimed — abort
  });

  if (!result.committed) return false;

  // Update game state: give card to claimer, make it their turn
  const gameRef = ref(db, `rooms/${roomId}/game`);
  const snap = await get(gameRef);
  const game = snap.val();
  const card = game.callWindow.card;

  const roomSnap = await get(ref(db, `rooms/${roomId}/playerOrder`));
  const playerOrder = roomSnap.val();
  const newPlayerIdx = playerOrder.indexOf(playerId);

  const hand = [...(game.hands[playerId] || []), card];
  const discardPile = (game.discardPile || []).filter(c => c.id !== card.id);

  await update(gameRef, {
    [`hands/${playerId}`]: hand,
    discardPile,
    currentPlayerIdx: newPlayerIdx,
    phase: 'action',
    'callWindow/active': false,
    'callWindow/claimedBy': playerId,
  });

  return true;
}

/** Call Kalooki — go out with entire hand at once */
export async function callKalooki(roomId, playerId, melds) {
  const gameRef = ref(db, `rooms/${roomId}/game`);
  const snap = await get(gameRef);
  const game = snap.val();

  const roomSnap = await get(ref(db, `rooms/${roomId}`));
  const room = roomSnap.val();

  // Place all melds
  const meldCardIds = new Set(melds.flatMap(m => m.cards.map(c => c.id)));
  const remaining = (game.hands[playerId] || []).filter(c => !meldCardIds.has(c.id));

  if (remaining.length > 0) return; // Must play all cards

  const existingMelds = Array.isArray(game.tableMelds)
    ? game.tableMelds
    : Object.values(game.tableMelds || {});

  const newMelds = [
    ...existingMelds,
    ...melds.map((m, i) => ({
      id: `meld_${playerId}_${Date.now()}_${i}`,
      playerId,
      type: m.type,
      cards: m.cards,
    })),
  ];

  await update(gameRef, {
    [`hands/${playerId}`]: [],
    tableMelds: newMelds,
    kalookiCaller: playerId,
  });

  await _endRound(roomId, playerId, true, { ...game, hands: { ...game.hands, [playerId]: [] } }, [], game.discardPile, room.playerOrder);
}

// ─── Round End ────────────────────────────────────────────────────────────────

async function _endRound(roomId, winnerId, isKalooki, game, _winnerHand, _discardPile, playerOrder) {
  const gameRef = ref(db, `rooms/${roomId}/game`);
  const roomRef = ref(db, `rooms/${roomId}`);

  // Get fresh hands
  const freshSnap = await get(gameRef);
  const freshGame = freshSnap.val();

  const roundScores = {};
  for (const pid of playerOrder) {
    if (pid === winnerId) {
      roundScores[pid] = 0;
    } else {
      const hand = freshGame.hands?.[pid] || [];
      const score = calcHandScore(hand);
      roundScores[pid] = isKalooki ? score * 2 : score;
    }
  }

  // Update total scores
  const roomSnap = await get(roomRef);
  const room = roomSnap.val();

  const totalUpdates = {};
  for (const pid of playerOrder) {
    const prev = room.players[pid]?.totalScore || 0;
    totalUpdates[`players/${pid}/totalScore`] = prev + roundScores[pid];
  }

  const round = freshGame.round;

  if (round >= 9) {
    // Game over
    await update(roomRef, {
      ...totalUpdates,
      status: 'gameOver',
      [`game/phase`]: 'gameOver',
      [`game/roundScores`]: roundScores,
      [`game/winner`]: winnerId,
    });
  } else {
    await update(roomRef, {
      ...totalUpdates,
      [`game/phase`]: 'roundEnd',
      [`game/roundScores`]: roundScores,
      [`game/winner`]: winnerId,
    });
  }
}

export async function advanceRound(roomId, hostId) {
  const gameRef = ref(db, `rooms/${roomId}/game`);
  const snap = await get(gameRef);
  const game = snap.val();
  const nextRound = (game.round || 1) + 1;

  if (nextRound > 9) {
    await update(ref(db, `rooms/${roomId}`), { status: 'gameOver' });
    return;
  }
  await startRound(roomId, nextRound, hostId);
}
