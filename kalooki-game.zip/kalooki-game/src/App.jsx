import { useState, useEffect } from 'react';
import { db } from './firebase';
import { ref, onValue } from 'firebase/database';
import Lobby from './components/Lobby';
import GameBoard from './components/GameBoard';

export default function App() {
  const [roomId, setRoomId] = useState(() => localStorage.getItem('kalooki_room'));
  const [playerId, setPlayerId] = useState(() => localStorage.getItem('kalooki_player'));
  const [playerName, setPlayerName] = useState(() => localStorage.getItem('kalooki_name') || '');
  const [roomData, setRoomData] = useState(null);
  const [loading, setLoading] = useState(!!localStorage.getItem('kalooki_room'));

  useEffect(() => {
    if (!roomId) {
      setLoading(false);
      return;
    }
    const roomRef = ref(db, `rooms/${roomId}`);
    const unsub = onValue(roomRef, snap => {
      const data = snap.val();
      if (!data) {
        // Room no longer exists
        handleLeave();
      } else {
        setRoomData(data);
        setLoading(false);
      }
    });
    return () => unsub();
  }, [roomId]);

  const handleJoin = (rId, pId, pName) => {
    setRoomId(rId);
    setPlayerId(pId);
    setPlayerName(pName);
    localStorage.setItem('kalooki_room', rId);
    localStorage.setItem('kalooki_player', pId);
    localStorage.setItem('kalooki_name', pName);
  };

  const handleLeave = () => {
    setRoomId(null);
    setPlayerId(null);
    setRoomData(null);
    localStorage.removeItem('kalooki_room');
    localStorage.removeItem('kalooki_player');
  };

  if (loading) {
    return (
      <div className="loading-screen">
        <div className="loading-logo">♠ Kalooki ♥</div>
        <div className="loading-spinner">Connecting…</div>
      </div>
    );
  }

  if (!roomId || !roomData) {
    return <Lobby onJoin={handleJoin} />;
  }

  return (
    <GameBoard
      roomData={roomData}
      playerId={playerId}
      playerName={playerName}
      roomId={roomId}
      onLeave={handleLeave}
    />
  );
}
