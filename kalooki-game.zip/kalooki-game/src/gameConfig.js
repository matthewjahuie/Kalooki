// Round configurations
export const ROUNDS = [
  { round: 1, cards: 9,  sets: 3, runs: 0, label: '3 Sets of 3' },
  { round: 2, cards: 10, sets: 2, runs: 1, label: '2 Sets of 3 + 1 Run of 4' },
  { round: 3, cards: 11, sets: 1, runs: 2, label: '1 Set of 3 + 2 Runs of 4' },
  { round: 4, cards: 12, sets: 0, runs: 3, label: '3 Runs of 4' },
  { round: 5, cards: 12, sets: 4, runs: 0, label: '4 Sets of 3' },
  { round: 6, cards: 13, sets: 3, runs: 1, label: '3 Sets of 3 + 1 Run of 4' },
  { round: 7, cards: 14, sets: 2, runs: 2, label: '2 Sets of 3 + 2 Runs of 4' },
  { round: 8, cards: 15, sets: 1, runs: 3, label: '1 Set of 3 + 3 Runs of 4' },
  { round: 9, cards: 16, sets: 0, runs: 4, label: '4 Runs of 4 — Super Kalooki' },
];

export const SUITS = ['hearts', 'diamonds', 'clubs', 'spades'];
export const RANKS = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

// Rank numeric value for run ordering (Ace = low = 1)
export const RANK_VALUES = {
  A: 1, '2': 2, '3': 3, '4': 4, '5': 5,
  '6': 6, '7': 7, '8': 8, '9': 9, '10': 10,
  J: 11, Q: 12, K: 13,
};

// For high-ace runs (...Q, K, A)
export const RANK_VALUES_HIGH = { ...RANK_VALUES, A: 14 };

export const SUIT_SYMBOLS = { hearts: '♥', diamonds: '♦', clubs: '♣', spades: '♠' };
export const RED_SUITS = new Set(['hearts', 'diamonds']);

/**
 * Card point value for scoring remaining hand cards
 * Black Ace = 1, Red Ace = 15, Face cards = 10, Joker = 50
 */
export function getCardValue(card) {
  if (!card) return 0;
  if (card.isJoker) return 50;
  if (card.rank === 'A') {
    return RED_SUITS.has(card.suit) ? 15 : 1;
  }
  if (['J', 'Q', 'K'].includes(card.rank)) return 10;
  return parseInt(card.rank, 10);
}

/** Create a full 108-card double deck with 4 jokers */
export function createDeck() {
  const deck = [];
  for (let d = 0; d < 2; d++) {
    for (const suit of SUITS) {
      for (const rank of RANKS) {
        deck.push({ suit, rank, id: `${suit}-${rank}-${d}`, isJoker: false });
      }
    }
    deck.push({ suit: 'joker', rank: 'JOKER', id: `joker-${d * 2}`, isJoker: true });
    deck.push({ suit: 'joker', rank: 'JOKER', id: `joker-${d * 2 + 1}`, isJoker: true });
  }
  return deck;
}

/** Fisher-Yates shuffle */
export function shuffleDeck(deck) {
  const d = [...deck];
  for (let i = d.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [d[i], d[j]] = [d[j], d[i]];
  }
  return d;
}

/** Calculate total score for cards remaining in hand */
export function calcHandScore(hand) {
  return hand.reduce((sum, card) => sum + getCardValue(card), 0);
}
