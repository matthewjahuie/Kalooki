import { RANK_VALUES, RANK_VALUES_HIGH } from './gameConfig';

/**
 * Validate a SET meld: 3+ cards of the same rank.
 * Jokers can substitute for any missing card.
 */
export function isValidSet(cards) {
  if (!cards || cards.length < 3) return false;
  const nonJokers = cards.filter(c => !c.isJoker);
  if (nonJokers.length === 0) return false; // all jokers not allowed
  const rank = nonJokers[0].rank;
  return nonJokers.every(c => c.rank === rank);
}

/**
 * Validate a RUN meld: 4+ consecutive cards of the same suit.
 * Jokers can fill gaps or extend at either end.
 * Tries both low-ace (A=1) and high-ace (A=14) interpretations.
 */
export function isValidRun(cards) {
  if (!cards || cards.length < 4) return false;
  const nonJokers = cards.filter(c => !c.isJoker);
  if (nonJokers.length === 0) return false;

  const suit = nonJokers[0].suit;
  if (suit === 'joker') return false;
  if (nonJokers.some(c => c.suit !== suit)) return false; // mixed suits

  // Check for duplicate non-joker ranks
  const rankSet = new Set(nonJokers.map(c => c.rank));
  if (rankSet.size !== nonJokers.length) return false;

  const n = cards.length;

  // Helper: given a rank-values map, check if all non-jokers fit in a window of n
  const fits = (rvMap) => {
    const vals = nonJokers.map(c => rvMap[c.rank]).sort((a, b) => a - b);
    const span = vals[vals.length - 1] - vals[0] + 1;
    // span must be <= n (jokers cover the gaps and extensions)
    // Also the minimum val must be >= 1 and max val <= 13 (or 14 for high ace)
    const maxAllowed = rvMap === RANK_VALUES_HIGH ? 14 : 13;
    return span <= n && vals[0] >= 1 && vals[vals.length - 1] <= maxAllowed;
  };

  if (fits(RANK_VALUES)) return true;

  // Try high ace if there's an ace in the non-jokers
  if (nonJokers.some(c => c.rank === 'A')) {
    if (fits(RANK_VALUES_HIGH)) return true;
  }

  return false;
}

/**
 * Check if a card can be laid off onto an existing meld.
 * @param {Object} card
 * @param {Object} meld - { type: 'set'|'run', cards: [] }
 */
export function canLayOff(card, meld) {
  if (!card || !meld) return false;

  if (meld.type === 'set') {
    if (card.isJoker) return true;
    const nonJokers = meld.cards.filter(c => !c.isJoker);
    if (nonJokers.length === 0) return false;
    return card.rank === nonJokers[0].rank;
  } else {
    // Run: test if adding the card still makes a valid run
    return isValidRun([...meld.cards, card]);
  }
}

/**
 * Check if a natural card can replace a joker in a meld.
 * Returns { canReplace: bool, jokerIndex: number } — which joker to replace.
 */
export function canReplaceJoker(naturalCard, meld) {
  if (!naturalCard || naturalCard.isJoker) return { canReplace: false };
  if (!meld.cards.some(c => c.isJoker)) return { canReplace: false };

  if (meld.type === 'set') {
    const nonJokers = meld.cards.filter(c => !c.isJoker);
    if (nonJokers.length === 0) return { canReplace: false };
    if (naturalCard.rank !== nonJokers[0].rank) return { canReplace: false };
    // Make sure the natural card isn't already in the meld
    if (meld.cards.some(c => !c.isJoker && c.id === naturalCard.id)) return { canReplace: false };
    const jokerIndex = meld.cards.findIndex(c => c.isJoker);
    return { canReplace: true, jokerIndex };
  } else {
    // For a run, try replacing each joker and see if it's still valid
    for (let i = 0; i < meld.cards.length; i++) {
      if (!meld.cards[i].isJoker) continue;
      const newCards = [...meld.cards];
      newCards[i] = naturalCard;
      if (isValidRun(newCards)) {
        return { canReplace: true, jokerIndex: i };
      }
    }
    return { canReplace: false };
  }
}

/**
 * Validate that proposed opening melds satisfy a round contract.
 * proposedMelds: Array of { type: 'set'|'run', cards: [] }
 * roundConfig: { sets: number, runs: number }
 */
export function validateOpening(proposedMelds, roundConfig) {
  const { sets: requiredSets, runs: requiredRuns } = roundConfig;
  const total = requiredSets + requiredRuns;

  if (proposedMelds.length !== total) {
    return { valid: false, error: `Need exactly ${total} melds (${requiredSets} set${requiredSets !== 1 ? 's' : ''}, ${requiredRuns} run${requiredRuns !== 1 ? 's' : ''})` };
  }

  let setCount = 0;
  let runCount = 0;

  for (let i = 0; i < proposedMelds.length; i++) {
    const { type, cards } = proposedMelds[i];
    if (type === 'set') {
      if (!isValidSet(cards)) {
        return { valid: false, error: `Meld ${i + 1}: not a valid set (need 3+ cards of same rank)` };
      }
      setCount++;
    } else if (type === 'run') {
      if (!isValidRun(cards)) {
        return { valid: false, error: `Meld ${i + 1}: not a valid run (need 4+ consecutive cards of same suit)` };
      }
      runCount++;
    } else {
      return { valid: false, error: `Meld ${i + 1}: must be 'set' or 'run'` };
    }
  }

  if (setCount !== requiredSets) {
    return { valid: false, error: `Need ${requiredSets} set${requiredSets !== 1 ? 's' : ''}, got ${setCount}` };
  }
  if (runCount !== requiredRuns) {
    return { valid: false, error: `Need ${requiredRuns} run${requiredRuns !== 1 ? 's' : ''}, got ${runCount}` };
  }

  return { valid: true, error: null };
}

/**
 * Get a sorted hand for display — group by suit for sets, by rank for runs
 */
export function sortHand(cards) {
  const suitOrder = { spades: 0, hearts: 1, diamonds: 2, clubs: 3, joker: 4 };
  const rankOrder = { A: 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10, J: 11, Q: 12, K: 13, JOKER: 14 };
  return [...cards].sort((a, b) => {
    if (suitOrder[a.suit] !== suitOrder[b.suit]) return suitOrder[a.suit] - suitOrder[b.suit];
    return rankOrder[a.rank] - rankOrder[b.rank];
  });
}
