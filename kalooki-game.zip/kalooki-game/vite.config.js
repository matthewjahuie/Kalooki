import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Change 'kalooki-game' to your GitHub repository name
export default defineConfig({
  plugins: [react()],
  base: '/kalooki-game/',
});
